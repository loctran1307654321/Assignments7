/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class ConcatenateTwoArrays {
    public static int[] concatenateArr(int []arr1,int arr2[])
    {
        int []arr=new int[arr1.length+arr2.length];
        for (int i = 0; i < arr1.length; i++) {
            arr[i]=arr1[i];
        }
        for (int i = 0; i < arr2.length; i++) {
            arr[arr1.length+i]=arr2[i];
        }
        return arr;
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.print("Enter number first Array: ");
        int n1 =scanner.nextInt();
        int []arr1=new int[n1];
        for (int i = 0; i < n1; i++) {
            System.out.print("Array["+i+"]= ");
            arr1[i]=scanner.nextInt();
        }
        System.out.print("Enter number first Array: ");
        int n2 =scanner.nextInt();
        int []arr2=new int[n2];
        for (int i = 0; i < n2; i++) {
            System.out.print("Array["+i+"]= ");
            arr2[i]=scanner.nextInt();
        }
        int []arr=concatenateArr(arr1,arr2);
        System.out.println("Array= "+Arrays.toString(arr));
    }
}
