/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class SortAndSearch {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        ArrayList<Integer> arrL=new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            System.out.print("Array["+i+"]= ");
            arrL.add(scanner.nextInt());
        }
        Collections.sort(arrL);
        System.out.print("Enter number in array: ");
        int n=scanner.nextInt();
        for (int i = 0; i < 5; i++) {
            if(n==arrL.get(i)){
                System.out.print("The number "+n+" was found at index "+i);
                break;
            }
        }
    }
}
