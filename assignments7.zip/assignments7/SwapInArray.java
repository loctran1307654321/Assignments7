/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class SwapInArray {
    public static void swapTwoElementArr(int[]arr,int index1,int index2)
    {
        int n=arr[index1]+arr[index2];
        arr[index1]=n-arr[index1];
        arr[index2]=n-arr[index2];
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter number of Array: ");
        int index1,index2;
        
        int n=scanner.nextInt();
        int []arr=new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Array["+i+"]= ");
            arr[i]=scanner.nextInt();
        }
        System.out.print("Enter index 1: ");
        index1=scanner.nextInt();
        System.out.print("Enter index 2: ");
        index2=scanner.nextInt();
        swapTwoElementArr(arr,index1, index2);
        System.out.println("Array= "+Arrays.toString(arr));
    }
    
}
