/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class ConvertArrayAndArrayList {
    public static ArrayList<String> arrayToArrayList(String[] array) {
        ArrayList<String> list = new ArrayList<>();
        for (String element : array) {
            list.add(element);
        }
        return list;
    }
    public static String[] arrayListToArray(ArrayList<String> list) {
        return list.toArray(new String[0]);
    }
    public static void main(String[] args) {

        String[] namesArray = {"Ann", "Bob"};
        ArrayList<String> namesList = arrayToArrayList(namesArray);
        System.out.println("ArrayList: " + namesList);

        ArrayList<String> peopleList = new ArrayList<>(List.of("Charles", "David"));
        String[] peopleArray = arrayListToArray(peopleList);
        System.out.println("Array: " + Arrays.toString(peopleArray));
    }

}
