
package assignments7;

import java.util.*;
import java.util.ArrayList;

public class UnlimitedDataEntry {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        ArrayList<Integer> arrL=new ArrayList<>();
        int n=0;
        int sum=0;
        int count=0;
        while(n!=-1)
        {
            System.out.print("Enter Number:  ");
            n=scanner.nextInt();
            sum+=n;
            arrL.add(n);
            count++;
        }
        
        System.out.println(Arrays.toString(arrL.toArray()));
            
        
        System.out.println(" The sum is: "+ sum);
    }
}

