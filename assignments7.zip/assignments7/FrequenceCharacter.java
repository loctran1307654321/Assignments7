/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class FrequenceCharacter {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter line: ");
        String str=scanner.nextLine();
        char []c=str.toCharArray();
        int []count=new int[26];
        for (char d : c) {
            if (d >= 'a' && d <= 'z') 
            {
                count[(int)d-97]++;
            }
            
        }
        for (int i = 0; i < 26; i++) {
            if(count[i]!=0){
                System.out.println((char)(i+97)+" : "+count[i]);
            }
        }
    }
}
