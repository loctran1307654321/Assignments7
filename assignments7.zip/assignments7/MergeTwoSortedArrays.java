/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;

public class MergeTwoSortedArrays {
    public static int[] sortArr(int []arr1, int [] arr2)
    {
        int []arr=new int [arr1.length+arr2.length];
        int k=arr1.length+arr2.length-1;
        int i=arr1.length-1;
        int j=arr2.length-1;
        while(i >= 0 && j >= 0){
            if(arr1[i]>arr2[j])
            {
                arr[k]=arr1[i];
                i--;
                k--;
            }else
            {
                if(arr1[i]<arr2[j])
                {
                    arr[k]=arr2[j];
                    j--;
                    k--;
                }else
                {
                    arr[k]=arr1[i];
                    arr[k-1]=arr1[i];
                    k-=2;
                    i--;
                    j--;
                }
            }
            
        }
        while(i>=0)
        {
            arr[k--]=arr1[i--];
        }
        while(j>=0)
        {
            arr[k--]=arr2[j--];
        }
        return arr;
    }
    public static void main(String[] args) {
        int []arr1=new int[]{1,3,4,5,7};
        int []arr2= new int[]{2,4,6,8};
        int []arr=sortArr(arr1, arr2);
        System.out.println("Array="+ Arrays.toString(arr));
    }
}
