/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class RemovingElements {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        ArrayList<Integer> arr=new ArrayList<>();
        while(true)
        {
            System.out.println("The program should allow the user to: ");
            System.out.println("1. Add a new task. ");  
            System.out.println("2. delete element of array >50");
            
            int n=scanner.nextInt();
            switch(n)
            {
                case 1: 
                    System.out.println("Enter Number: ");
                    arr.add(scanner.nextInt());
                    break;
                case 2:
                    for(int i = arr.size()-1; i >=0; i--)
                    {
                        if(arr.get(i)>50){
                            arr.remove(i);
                            
                        }
                    }
                    System.out.println("Array="+Arrays.toString(arr.toArray()));
                    break;
                    

                default:         
                    return ;
            }
        }
        
    }
}
