/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class SecondLargestElement {
    
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        System.out.println("Enter number of Array: ");
        int largest=Integer.MIN_VALUE;
        int secondLargest=Integer.MIN_VALUE;
        int n=scanner.nextInt();
        int []arr=new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Array["+i+"]= ");
            arr[i]=scanner.nextInt();
            
        }
        for (int i = 0; i < n; i++) {
            if(largest<arr[i])
            {
                secondLargest=largest;
                largest=arr[i];
                
            }else
            {
                if(arr[i]>secondLargest&&arr[i]!=largest)
                {
                    secondLargest=arr[i];
                }
            }
        }
        if(secondLargest==Integer.MIN_VALUE)
        {
            System.out.println("there is no second largest ");
        }else{
            System.out.println("second largest is: "+ secondLargest);
        }
    }
}
