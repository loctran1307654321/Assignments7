/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignments7;

import java.util.*;
public class RemoveDuplicateElements {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter number of array: ");
        int n=scanner.nextInt();
        ArrayList<Integer> arrL=new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.print("Array["+i+"]= ");
            arrL.add(scanner.nextInt());
        }
        for (int i = 0; i < arrL.size()-1; i++) {
            for (int j = i+1; j <arrL.size() ; j++) {
                if(arrL.get(i).equals(arrL.get(j)))
                {
                    arrL.remove(j);
                }
            }
        }
        System.out.print("Array= ");
        System.out.print(Arrays.toString(arrL.toArray()));
    }
}
